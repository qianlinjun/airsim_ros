octomap_rviz_plugins
====================

RViz display plugins for visualizing octomap messages (ROS groovy and later):
http://ros.org/wiki/octomap_rviz_plugins
