#ifndef _PID_H_
#define _PID_H_

#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <assert.h>
#include <iostream> 
#include <sys/time.h> 

using namespace std;

class PID
{
public:
    PID();
    ~PID();
    void setParam(double kP, 
                  double kI, 
                  double kD, 
                  double threshold_I = 20.0,
                  double sample_time = 10);//ms

    double getOutputByPos(double curerr);//位置式PID控制
	double getOutputByAdd(double curerr);//增量式PID控制，计算简单，过渡效果更好
    
private:
    double sample_time;//采样时间
    struct timeval last_time, current_time;//上一次和本次系统时间(ms)    
    double prev_err, last_err;//上上次误差(用于增量式PID)、上次误差
    
    double kP, kI, kD;//系数
    double PTerm, ITerm, DTerm;
    double threshold_I;//累计积分上限
    
	double lastPIDOut;//上一次PID控制结果
};

#endif



