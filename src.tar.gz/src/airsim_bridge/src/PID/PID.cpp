#include"PID.h"
using namespace std;

//位置式PID

PID::PID()
{
    PTerm=0;
    ITerm=0;
    DTerm=0;
    
    prev_err = 0;//上上次误差
    last_err = 0;//上次误差
	lastPIDOut=0;//上一次输出结果
}

PID::~PID()
{
}
    
void PID::setParam(double kP, double kI, double kD, double threshold_I,double sample_time)
{
    this->kP = kP;
    this->kI = kI;
    this->kD = kD;
    this->threshold_I = threshold_I;
    this->sample_time = sample_time;
    
    gettimeofday(&last_time, NULL);
}

double PID::getOutputByPos(double error)
{  
    double PIDOut=0;
    gettimeofday(&current_time, NULL);
    double t1 = (double)last_time.tv_sec * 1000 + (double)last_time.tv_usec / 1000;
    double t2 = (double)current_time.tv_sec * 1000 + (double)current_time.tv_usec / 1000;
    
    double delta_time = t2 - t1;//ms
    double delta_error = error - last_err;

    if (delta_time >= sample_time)
    {    
        PTerm = kP * error;
        ITerm += error * delta_time/1000;

        //积分上限限制
        if (ITerm < -threshold_I)
            ITerm = -threshold_I;
        else if(ITerm > threshold_I)
            ITerm = threshold_I;

        DTerm = 0.0;
        if (delta_time > 0)
            DTerm = delta_error*1000 / delta_time;

        last_time = current_time;
        last_err = error;

        cout <<endl<< "PTerm:" << PTerm<< " ITerm" << ITerm << "　DTerm:" << DTerm <<endl; 
        PIDOut = PTerm + kI * ITerm + kD * DTerm;
        
        //油门范围０－１
        if(PIDOut>0.1)
            PIDOut=0.1;
        else if(PIDOut<-0.1)
            PIDOut=-0.1;
        PIDOut=PIDOut+0.564;//0.6127飞机基本悬停
    }
    return PIDOut;
}

//增量式PID
double PID::getOutputByAdd(double error)
{	
    cout << endl;
	cout << " prev_err" << prev_err << " prev_err" << prev_err<< " error" << error<<endl; //
	PTerm = kP *(error-last_err);
	ITerm = kI * error;
	DTerm = kD *(error- 2*last_err + prev_err);
    //cout << "P:" << P << "D:" << D <<endl; //<< " _I" << _I
    double pwm_value = PTerm + ITerm +DTerm;//增量结果
	
	/*if(pwm_value > 20)
	   pwm_value = 10;
	if(pwm_value < -20)
       pwm_value = -10;*/
	
	double PIDOut = lastPIDOut + pwm_value;
    cout << "PIDOut:"<<PIDOut<<endl<<endl;
	lastPIDOut = PIDOut;
    prev_err = last_err;
    last_err = error;
    
	/*if(PIDOut > 20)
	   PIDOut = 20;
	if(PIDOut < -20)
       PIDOut = -20;
    PIDOut = (PIDOut+20)/40;*/
    
	return PIDOut;     
}

