octomap_mapping
===============

ROS stack for mapping with OctoMap, contains the octomap_server package.

The `master` branch tracks the latest (stable) releases. Please send pull requests against the latest development branch, e.g. `indigo-devel`.

Imported from SVN, see https://code.google.com/p/alufr-ros-pkg/ for the previous versions.
