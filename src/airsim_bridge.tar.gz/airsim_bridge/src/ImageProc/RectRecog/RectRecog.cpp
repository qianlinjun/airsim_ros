#include "RectRecog.h"

RectRecog::RectRecog():scale(0.6),thresh(50)
{
}

RectRecog::~RectRecog()
{
}

// from pt0->pt1 and from pt0->pt2
double RectRecog::getAngle(Point pt1, Point pt2, Point pt0)
{
    double dx1 = pt1.x - pt0.x;
    double dy1 = pt1.y - pt0.y;
    double dx2 = pt2.x - pt0.x;
    double dy2 = pt2.y - pt0.y;
    return (dx1*dx2 + dy1*dy2) / sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}

bool RectRecog::isWhiteSquare(Mat& image_S,vector<Point>& square)
{
    int maxX, minX, maxY, minY;
    int count=0;
    maxX = maxY = 0;
    minX = square[0].x;  minY = square[0].y;
    for (int i = 0; i < square.size(); i++)
    {
        maxX =  square[i].x > maxX ?  square[i].x :maxX;
        minX =  square[i].x < minX ? square[i].x : minX;
        maxY =  square[i].y > maxY ?  square[i].y : maxY;
        minY =  square[i].y < minY ? square[i].y : minY;
    }
    Rect rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
    Mat roImg(image_S,rect);
    for(int i=0;i<roImg.rows;i++)
    {
        uchar* data=roImg.ptr<uchar>(i);
        for(int j=0;j<roImg.cols;j++)
        {
            if(data[j]==0)
                ++count;
        }
    }
    if(count>0.4*roImg.cols*roImg.rows)
        return true;
    else
        return false;
}


// returns sequence of squares detected on the image.
// the sequence is stored in the specified memory storage
bool RectRecog::getSquarePts(const Mat& image, vector<vector<Point> >& squares)
{
    bool isGetSquares = false;
    squares.clear();   //数组清空
    Mat image_down, image_up, gray0(image.size(), CV_8U), image_edge,image_gray;
    Mat imageHSV, image_S, image_S_threshold, image_meanfilter;
    
    
    cvtColor(image, image_gray, CV_RGB2GRAY);
    
    blur(image, image_meanfilter, Size(10, 10));//均值滤波
    
    cvtColor(image_meanfilter, imageHSV, CV_BGR2HSV);     //将image转到HSV空间
    image_S.create(imageHSV.size(), imageHSV.depth());   //定义与imageHSV同尺寸和深度的图像image_S
    int ch1[] = { 1, 0 };
    mixChannels(&imageHSV, 1, &image_S, 1, ch1, 1);   //将imageHSV的S层复制到image_S
    threshold(image_S,image_S_threshold,18,255,CV_THRESH_BINARY);//0-20 黑(0) 20-255白()
    
    //对图像去燥
    pyrDown(image_gray, image_down, Size(image.cols / 2, image.rows / 2));
    pyrUp(image_down, image_up, image.size());
    vector<vector<Point> > contours;   //保存检测到的矩形边缘点的数组
    int ch[] = { 0, 0 };
    mixChannels(&image_up, 1, &gray0, 1, ch, 1);  //将去燥后的image复制到gray0
 
    
     //Canny(gray0, image_edge, 0, 100, 5);         //Canny算子边缘处理
     Canny(image_S_threshold, image_edge, 0, 50, 5);         //Canny算子边缘处理
     dilate(image_edge, image_edge, Mat(), Point(-1, -1)); //对边缘处理得结果做膨胀处理

    //imshow("image_S",image_S);
    imshow("image_S_threshold",image_S_threshold);
     imshow("image_edge",image_edge);
     
    //CV_RETR_LIST将检测出的每个轮廓（相互独立）以拐点(CV_CHAIN_APPROX_SIMPLE)的形式存储到contours中
     findContours(image_edge, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
     vector<Point> approx;   //存储矩形4个顶点的坐标的数组
    
     vector<Rect> boundRect( contours.size() );//包围点集的最小矩形vector

     for (size_t i = 0; i < contours.size(); i++)
     {
         approxPolyDP(Mat(contours[i]), approx, arcLength(Mat(contours[i]), true)*0.02, true);//输出封闭的多边形顶点点集
         
         
         //cout<<"approx.size()"<<approx.size();
         //判断是否为四边形等条件
         //approx.size() == 4 && fabs(contourArea(Mat(approx))) > 1000 && isContourConvex(Mat(approx))
         if (approx.size() <8 && fabs(contourArea(Mat(approx))) > 1000)
         {
             boundRect[i] = boundingRect( Mat(approx) );         //计算并返回包围轮廓点集的最小矩形
             rectangle( image, boundRect[i].tl(), boundRect[i].br(), (0, 0, 255), 2, 8, 0 );//画矩形，tl矩形左上角，br右上角
             
             double maxCosine = 0;

             for (int j = 2; j < 5; j++)
             {
                 double cosine = fabs(getAngle(approx[j % 4], approx[j - 2], approx[j - 1]));   //计算夹角余弦值
                 maxCosine = MAX(maxCosine, cosine);
             }

             //如果三个夹角余弦值都小于0.3则说明是矩形，并存储矩形
             if (maxCosine < 0.3 && isWhiteSquare(image_S_threshold,approx) && abs(approx[0].x-approx[1].x)<600 && abs(approx[1].x-approx[2].x)<600)
             {
                 squares.push_back(approx);//squares two dimesion
                 isGetSquares=true;
             }
         }
     }//for contours.size
    imshow("image_S_threshold",image_S_threshold);
    return isGetSquares;
}

//旋转图像中点的函数
Point RectRecog::getPointAffinedPos(const Point &src, const Point center, double angle)
{
    Point dst;
    int x = src.x - center.x;
    int y = src.y - center.y;

    dst.x = cvRound(x * cos(angle) + y * sin(angle) + center.x);
    dst.y = cvRound(-x * sin(angle) + y * cos(angle) + center.y);

    dst.x = (dst.x - center.x)*scale + center.x;
    dst.y = (dst.y - center.y)*scale + center.y;

    return dst;
}

//裁切
void RectRecog::cutImg( Mat& image, vector<vector<Point> > squares,Mat &rectResult)
{
    int i = 0;
    vector<Point>longside;   //存储矩形长边的两个顶点
    double a = (squares[i][0].x - squares[i][1].x)*(squares[i][0].x - squares[i][1].x) + (squares[i][0].y - squares[i][1].y)*(squares[i][0].y - squares[i][1].y);
    double b = (squares[i][1].x - squares[i][2].x)*(squares[i][1].x - squares[i][2].x) + (squares[i][1].y - squares[i][2].y)*(squares[i][1].y - squares[i][2].y);

    if (a > b)
    {
        longside.push_back(squares[i][0]);
        longside.push_back(squares[i][1]);
    }
    else
    {
        longside.push_back(squares[i][1]);
        longside.push_back(squares[i][2]);
    }

    Mat rot(2, 3, CV_32FC1);   //旋转矩阵
    Mat rotMat = Mat::zeros(image.size(), image.type());   //定义旋转后的矩阵

    Point center = Point(rotMat.cols / 2, rotMat.rows / 2);   //旋转中心
    double angle = atan((longside[0].y - longside[1].y) / ((longside[0].x - longside[1].x)+0.00000001))*180/pi;   //旋转角度
    if(abs(angle)>45)
        angle=90-abs(angle);
    scale = image.rows/sqrt(image.cols*image.cols+image.rows*image.rows);   //缩放参数

    rot = getRotationMatrix2D(center, angle, scale);    //获得旋转矩阵
    warpAffine(image, rotMat, rot, image.size());    //旋转并缩放图像

    vector<Point>resultPoint;   //存储旋转后矩形的4个顶点
    Point point;
    for (int i = 0; i < 4; i++)
    {
        point = getPointAffinedPos(squares[0][i], Point(image.cols/2, image.rows/2), angle*pi/180);
        resultPoint.push_back(point);   //存储顶点
    }
    //获得矩形的bounding box(近似于矩形本身)
    int maxX, minX, maxY, minY;
    maxX = maxY = 0;
    minX = resultPoint[0].x;  minY = resultPoint[0].y;
    for (int i = 0; i < resultPoint.size(); i++)
    {
        maxX =  resultPoint[i].x > maxX ?  resultPoint[i].x : maxX;
        minX =  resultPoint[i].x < minX ? resultPoint[i].x : minX;
        maxY =  resultPoint[i].y > maxY ?  resultPoint[i].y : maxY;
        minY =  resultPoint[i].y < minY ? resultPoint[i].y : minY;
    }
    //裁剪矩形并存储到新图像中
    Rect rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
    //cout<<minX<<" "<<minY<<" "<<maxX<<" "<<maxY<<endl;
    //rectangle(rotMat, rect, (0, 0, 255), 2, 8, 0);
    Mat temp(rotMat, rect);

    Mat temp_hsv;
    cvtColor(temp, temp_hsv, COLOR_BGR2HSV);

    Mat temp_S;
    temp_S.create(temp_hsv.size(),temp_hsv.depth());
    int ch1[] = { 1, 0 };
    mixChannels(&temp_hsv, 1, &temp_S, 1, ch1, 1);

    Mat Image(temp_S.size(),CV_8U);
    for(int i=0;i<Image.rows;i++)
    {
        uchar* data = Image.ptr<uchar>(i);
        uchar* data1 = temp_S.ptr<uchar>(i);
        for(int j=0;j<Image.cols;j++)
           {
               if(data1[j]>32)
                 data[j]=0;
               else
                 data[j]=255;
           }
     }
    rectResult = Image;
    //imshow("cutimage", Image);


   /* char path[255]={0};
    memset(path,'\0',sizeof(char)*255);
   char prefix[]="/home/exbot/图片/Webcam/";
   char postfix[]=".jpg";
    framenum++;
    sprintf(path,"%sframe_%04d%s",prefix,framenum,postfix);
    imwrite(path,temp);*/
}


// the function draws all the squares in the image
void RectRecog::drawSquares(Mat& image, const vector<vector<Point> >& squares)
{
    int maxX, minX, maxY, minY;
    for (int i = 0; i < squares.size(); i++)
    {
        maxX = maxY = 0;
        minX = squares[i][0].x;  minY = squares[i][0].y;
        for (int j = 0; j < 4; j++)
        {
            maxX = maxX > squares[i][j].x ? maxX : squares[i][j].x;
            minX = minX < squares[i][j].x ? minX : squares[i][j].x;
            maxY = maxY > squares[i][j].y ? maxY : squares[i][j].y;
            minY = minY < squares[i][j].y ? minY : squares[i][j].y;
        }
        Point point1, point2;
        point1.x = minX; point1.y = minY;
        point2.x = maxX; point2.y = maxY;

        rectangle(image, point1, point2, (0, 0, 255), 2, 8, 0);   //画矩形
    }
}


bool RectRecog::findSquares(Mat &image,Mat &resultImage)
{
        bool isFindSquares = false;
        vector<vector<Point> > squarePts;
        isFindSquares = getSquarePts(image , squarePts);
        if( isFindSquares )
        {
            cutImg(image, squarePts,resultImage);
            cout<<"squares num:"<<squarePts.size()<<endl;
        }else
            cout<<"no squares!"<<endl;
        drawSquares(image, squarePts);
    imshow("rectangle recong result", image);
        waitKey(20);
        return isFindSquares;
}



/*for (int i = 0; i < image_S.rows; i++)
{
    uchar* data = image_S.ptr<uchar>(i);
    for (int j = 0; j < image_S.cols; j++)
    {
        if (data[j] >= 0 && data[j] <= 20)
            data[j] = 0;
        else
            data[j] = 255;
    }
}*/