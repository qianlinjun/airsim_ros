#ifndef RECTRECOG_H
#define RECTRECOG_H

#include "opencv2/opencv.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"

#include "opencv2/features2d/features2d.hpp"

#define pi 3.1415926  //圆周率常量
using namespace std;
using namespace cv;

//矩形检测
class RectRecog
{
public:
  RectRecog();
  ~RectRecog();
	
  //计算向量 pt0->pt1， pt0->pt2夹角
  Point getPointAffinedPos(const Point &src, const Point center, double angle);
  bool isWhiteSquare(Mat& image_H,vector<Point>&square);
  double getAngle(Point pt1, Point pt2, Point pt0);
  void cutImg( Mat& image, vector<vector<Point> > squares,Mat &rectResult);
  //void BackProject(Mat& image_H, Mat& templateMat_H , Mat& backprojResult);
  // returns sequence of squares detected on the image
  bool getSquarePts(const Mat& image, vector<vector<Point> >& squares);
  // the function draws all the squares in the image
  void drawSquares(Mat& image, const vector<vector<Point> >& squares);
  bool findSquares(Mat& image,Mat &resultImage);
  
private:
  double scale;
  int thresh ;//Canny算子边缘检测的参数
};

#endif

